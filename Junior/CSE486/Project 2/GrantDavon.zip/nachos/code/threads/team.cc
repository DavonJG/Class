#include "team.h"

Team::Team(){

}

Team::~Team(){

}

void
Team::setName(char* name){
        teamName = name;
}
char*
Team::getName(){
	return teamName;
}

void
Team::setID(int id){
	teamID = id;
}
int
Team::getID(){
	return teamID;
}

bool
Team::operator== (Team &team){
	return (this->getID() == team.getID());
}
