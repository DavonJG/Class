// stack.cc

#include "stack.h"

Stack::Stack(int sz){
	size = sz;
	top  = 0;
	stack = new int[size];
}

Stack::~Stack(){
	delete stack;
}

void
Stack::Push(int value) {
	if(!Full()){
		stack [top++] = value;
	}
}

int
Stack::Pop(){
	if(top >= 0){
		int *pop = &stack[top-1];
		stack[top] = 0;
		top--;
		return (*pop);
	}else{
		return 0;
	}
}

bool
Stack::Full(){
	return (top == size);
}
