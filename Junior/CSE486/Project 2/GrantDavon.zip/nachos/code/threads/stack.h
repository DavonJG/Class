// stack.h
#ifndef STACK_H
#define STACK_H

class Stack{
public:
	Stack(int sz);
	~Stack();
	void Push(int value);
	int Pop();
	bool Full();
private:
	int size;
	int top;
	int *stack;
};

#endif /* STACK_H */
