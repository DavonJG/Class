
class Team{
	public:
		Team();
		~Team();
		void setName(char* name);
		char* getName();
		void setID(int id);
		int getID();
		bool operator== (Team &team);
	private:
		int teamID;
		char* teamName;
		int size;
};
