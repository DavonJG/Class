#include "kernel.h"
#include "main.h"
#include "thread.h"
#include "team.h"
#include "list.h"

void
SimpleThread(int which)
{
    int num;
    
    for (num = 0; num < 5; num++) {
        printf("*** thread %d looped %d times\n", which, num);
	printf("Hello World\n");
        kernel->currentThread->Yield();
    }
}

void
PrintT(Team team){
	printf("%s\n", team.getName());
}

void
ThreadTest()
{
    Thread *t = new Thread("forked thread");
    t->Fork((VoidFunctionPtr) SimpleThread, (void *) 1);
    
   // SimpleThread(0);
    List<Team> *teamList = new List<Team>();
    Team *team1 = new Team();
	team1->setID(1);
	team1->setName("Philadelphia Eagles");
    Team *team2 = new Team();
	team2->setID(2);
	team2->setName("New England Patriots");
    Team *team3 = new Team();
	team3->setID(3);
	team3->setName("The Waterboys");

    teamList->Append(*team1);
    teamList->Append(*team2);
    teamList->Append(*team3);

    teamList->Apply(PrintT);
}
