#include <time.h>
#include "kernel.h"
#include "main.h"
#include "synch.h"
#include "thread.h"

class Buffer {
public:
  Buffer(int capacity) {
    head = 0;
    tail = 0;
    size = 0;
    cap = capacity;
    content = new int[cap];
  }
  void Add(int v) {
    if (size == cap) {
      printf("Error: buffer overflow!\n");
      kernel->currentThread->Yield();
      return;
    }
    ++size;
    RandomYield();
    content[tail] = v;
    RandomYield();
    tail = (tail + 1) % cap;
  }
  int Remove() {
    int v;
    if (size == 0) {
      printf("Error: buffer underflow!\n");
      kernel->currentThread->Yield();
      return 0;
    }
    --size;
    RandomYield();
    v = content[head];
    RandomYield();
    head = (head + 1) % cap;
    return v;
  }
private:
  void RandomYield() {
    int times = rand() % 3;
    int i;
    for (i = 0; i < times; ++i) {
      kernel->currentThread->Yield();
    }
  }
  int head;
  int tail;
  int size;
  int cap;
  int* content;
};

Buffer *buffer = new Buffer(10);
Semaphore *mutex = new Semaphore("mutex", 1);
Semaphore *empty = new Semaphore("empty", 10);
Semaphore *full = new Semaphore("full", 0);

//----------------------------------------------------------------------
// Producer
//  Produces items and fills the buffer.
//----------------------------------------------------------------------

void
Producer(int id)
{
  int i;
  for (i = 1; i <= 20; ++i) {
    empty->P();
    mutex->P();
    buffer->Add(i);
    printf("Producer producing item %d\n", i);
    mutex->V();
    full->V();
  }
}

//----------------------------------------------------------------------
// Consumer
//  Consumes items and empties the buffer.
//----------------------------------------------------------------------

void
Consumer(int id)
{
  int i;
  for (i = 1; i <= 20; ++i) {
    full->P();
    mutex->P();
    printf("Consumer consuming item %d\n", buffer->Remove());
    mutex->V();
    empty->V();
  }
}

//----------------------------------------------------------------------
// ThreadTest
//  Entry point for the producer-consumer problem solution.
//----------------------------------------------------------------------

void
ThreadTest()
{
  srand(time(NULL));

  Thread *c1 = new Thread("consumer 1");
  c1->Fork((VoidFunctionPtr) Consumer, (void *) 1);

  Thread *p1 = new Thread("producer 1");
  p1->Fork((VoidFunctionPtr) Producer, (void *) 1);
}
