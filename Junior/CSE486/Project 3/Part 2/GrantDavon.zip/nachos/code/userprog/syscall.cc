#include "syscall.h"

extern void RunUserProg(void*);
SpaceId Exec(char* progName){
 progName = new char[999];
 int temp = 1;
 int i = 0;
 int reg = kernel->machine->ReadRegister(4);
 kernel->machine->ReadMem(reg,1,&temp);
 while(temp != '/0'){
   progName[i] = temp;
   i++;reg++;
   kernel->machine->ReadMem(reg,1,&temp);
 }
 printf("%s", progName);
 progName[i] = (char)temp;
 Thread *pt = new Thread(progName);
 pt->Fork((VoidFunctionPtr)RunUserProg, (void*)progName);
}
