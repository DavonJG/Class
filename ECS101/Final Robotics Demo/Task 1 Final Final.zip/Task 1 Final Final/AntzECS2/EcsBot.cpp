/*
 * Antz
 * Antz Framework
 * EcsBot.cpp
 * ECS 101 student code.
 * Copyright (c) 2015 ELi Goldweber. All rights reserved.
 * License: <#license#>
 */
#include "EcsBot.h"

using namespace Antz;

/* EcsBot -- Contructor */
EcsBot::EcsBot(uint32_t robotId):
AntzRobot(robotId){}

/* setup -- setup routine for EcsBot */
void EcsBot::setup() {
  
    AntzRobot::setup();
    Serial.begin(9600);
}

/* loop -- loop routine for EcsBot */
void EcsBot::loop() {

  float distance;
  int count;
  int turnAway = 15;
  /*
   * By checking 5 positions we can assure that the robot will not
   * hit any of the objects
   */
  int position1 = 5; 
  int position2 = 45;
  int position3 = 90;
  int position4 = 135;
  int position5 = 175;

   count = 0;

  //position 1 check
  scanner.scanAt(position1);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
  
  
  //position 2 check
  scanner.scanAt(position2);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
 

  //position 3 check
  scanner.scanAt(position3);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  


  //position 4 check
  scanner.scanAt(position4);
  delay(100);
  
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
  delay(100);

  //position 5 check
  scanner.scanAt(position5);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  

  
 
 int number = random(0,2);
  
  if (count > 0)
  {
    if (number == 0){
       turnLeft(90);
       delay(200);
    }
    else {
       turnRight(90);
       delay(200);
    }
  }
  else 
  {
    goForward(250);
    delay(400);
  }
  
   


 
  }
