/*
 * Antz
 * Antz Framework
 * EcsBot.cpp
 * ECS 101 student code.
 * Copyright (c) 2015 ELi Goldweber. All rights reserved.
 * License: <#license#>
 */
#include "EcsBot.h"

using namespace Antz;

/* EcsBot -- Contructor */
EcsBot::EcsBot(uint32_t robotId):
AntzRobot(robotId){}

/* setup -- setup routine for EcsBot */
void EcsBot::setup() {
  
    AntzRobot::setup();
    Serial.begin(9600);
}

/* loop -- loop routine for EcsBot */
void EcsBot::loop() {

  float distance;
  int count;
  int turnAway = 15;

  /*
   * By checking 5 positions we can assure that the robot will not
   * hit any of the objects
   */
  int position1 = 5; 
  int position2 = 45;
  int position3 = 90;
  int position4 = 135;
  int position5 = 175;

   count = 0;

  //position 1 check
  scanner.scanAt(position1);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
 
  
  //position 2 check
  scanner.scanAt(position2);
   delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
 

  //position 3 check
  scanner.scanAt(position3);
  delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
 

  //position 4 check
  scanner.scanAt(position4);
   delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  
 

  //position 5 check
  scanner.scanAt(position5);
   delay(100);
  distance = scanner.getDistanceFront();
  if (distance <= turnAway)
  {
    count +=1;
  }  


display.number(true,0);
int sig[6] = {0};
for(int i =0; i<=5; i++)
{
  sig[i] = receiveSignal(i);
}
for(int i =0; i<=5; i++)
{
  if(sig[i] == 2)
  {
    display.number(true,2);
    delay(90000);
  }
}
if(sig[0] == 1)
{
  display.number(true,1);
  if(count>0)
  {
    turnRight(90);
    delay(500);
  }
  else
  {
    goForward(500);
    delay(500);
  }
}
else if(sig[1] == 1)
{
    display.number(true,1);
    turnRight(60);
    delay(500);
}
 
else if(sig[5] == 1)
{
  display.number(true,1);
    turnLeft(60);
    delay(500);
 
}
else if(sig[2] == 1)
{
  display.number(true,1);
    turnRight(120);
    delay(600);
 
}
else if(sig[4] == 1)
{
  display.number(true,1);
    turnLeft(120);
    delay(600);
 
}
else if(sig[3] == 1)
{
  display.number(true,1);
    turnLeft(180);
    delay(700);
 
}
else
{
  if(count>0)
  {
    turnRight(90);
    delay(500);
  }
  else
  {
    goForward(500);
    delay(500);
  }



}
   
}

 
  
