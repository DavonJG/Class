import java.io.*;

public class Sample2 {
  public static void main (String[] argv)  {
    System.out.println("Hello, World again!");
  }
}