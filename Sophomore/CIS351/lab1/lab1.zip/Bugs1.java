// There are five syntax errors in this little
// program.  To start you out finding and fixing
// them, there is a missing " on line 9.

import java.io.*;                      

public class Bugs1 { //renamed class to Bugs1
  public static void main(String argv[]) { //added missing static
    System.out.println("Hello, World!"); //added missing " and missing ;
  }
} //added missing }

//fixed indentation