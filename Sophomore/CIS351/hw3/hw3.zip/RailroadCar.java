public class RailroadCar{
  double weight;
  int yearMade;
}